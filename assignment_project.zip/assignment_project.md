```python
class MyClass:
    static_var = 5  # Static variable

obj1 = MyClass()
obj2 = MyClass()

print(obj1.static_var)  # Output: 5
print(obj2.static_var)  # Output: 5

MyClass.static_var = 10  # Modify static variable
print(obj1.static_var)  # Output: 10
print(obj2.static_var)  # Output: 10

```


```python

```

2 Dynamic Variables: Instance-specific variables that are defined within methods. Each object of a class can have different values for dynamic variables.


```python
class MyClass:
    def __init__(self, value):
        self.dynamic_var = value  # Dynamic variable

obj1 = MyClass(5)
obj2 = MyClass(10)

print(obj1.dynamic_var)  # Output: 5
print(obj2.dynamic_var)  # Output: 10

```

2. Purpose of pop(), popitem(), clear() in a Dictionary


```python
my_dict = {'a': 1, 'b': 2, 'c': 3}
value = my_dict.pop('b')
print(value)  # Output: 2
print(my_dict)  # Output: {'a': 1, 'c': 3}

```


```python
my_dict = {'a': 1, 'b': 2, 'c': 3}
item = my_dict.popitem()
print(item)  # Output: ('c', 3)
print(my_dict)  # Output: {'a': 1, 'b': 2}

```


```python
my_dict = {'a': 1, 'b': 2, 'c': 3}
my_dict.clear()
print(my_dict)  # Output: {}

```

3. What is FrozenSet? Explain with Suitable Examples


```python
normal_set = {1, 2, 3}
frozen_set = frozenset([1, 2, 3])

print(frozen_set)  # Output: frozenset({1, 2, 3})

# frozen_set.add(4)  # This will raise an AttributeError since it's immutable

```

4. Difference Between Mutable and Immutable Data Types in Python


```python
my_list = [1, 2, 3]
my_list[0] = 10  # The list is modified
print(my_list)  # Output: [10, 2, 3]

```


```python
my_string = "hello"
# my_string[0] = "H"  # This will raise a TypeError because strings are immutable

```

5. What is __init__? Explain with an Example


```python
class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

person = Person("John", 25)
print(person.name)  # Output: John
print(person.age)  # Output: 25

```

What is a Docstring in Python? Explain with an Example


```python
def add(a, b):
    """This function adds two numbers and returns the result."""
    return a + b

print(add.__doc__)  # Output: This function adds two numbers and returns the result.

```


```python
def add(a, b):
    """This function adds two numbers and returns the result."""
    return a + b

print(add.__doc__)  # Output: This function adds two numbers and returns the result.

```


```python
7. What are Unit Tests in Python?
```


```python
7. What are Unit Tests in Python
```


```python
import unittest

def add(a, b):
    return a + b

class TestAddFunction(unittest.TestCase):
    def test_add(self):
        self.assertEqual(add(2, 3), 5)
        self.assertEqual(add(-1, 1), 0)

if __name__ == '__main__':
    unittest.main()

```


```python
8. What is break, continue, and pass in Python?
```


```python
8. What is break, continue, and pass in Python
```


```python
for i in range(5):
    if i == 3:
        break
    print(i)
# Output: 0 1 2

```


```python
for i in range(5):
    if i == 3:
        continue
    print(i)
# Output: 0 1 2 4

```


```python
for i in range(5):
    if i == 3:
        pass  # Do nothing
    print(i)
# Output: 0 1 2 3 4

```


```python
9. What is the Use of self in Python?

```


```python
9. What is the Use of self in Python
```


```python
class MyClass:
    def __init__(self, value):
        self.value = value

    def display(self):
        print(self.value)

obj = MyClass(10)
obj.display()  # Output: 10

```

10. What are Global, Protected, and Private Attributes in Python?10. What are Global, Protected, and Private Attributes in Python?


```python
global_var = 10

class MyClass:
    def show_global(self):
        print(global_var)

```


```python
class MyClass:
    def __init__(self):
        self._protected_var = 10

    def show_protected(self):
        print(self._protected_var)

obj = MyClass()
obj.show_protected()  # Output: 10
print(obj._protected_var)  # Output: 10 (accessible, but not recommended)

```


```python
class MyClass:
    def __init__(self):
        self.__private_var = 10

    def show_private(self):
        print(self.__private_var)

obj = MyClass()
obj.show_private()  # Output: 10
# print(obj.__private_var)  # This will raise an AttributeError
print(obj._MyClass__private_var)  # Output: 10 (access via name mangling)

```


```python
11. What are Modules and Packages in Python?
```


```python
11. What are Modules and Packages in Python
```

Modules: A module is a single Python file that contains definitions and implementations of functions, classes, and variables. Modules allow you to logically organize your Python code and reuse it across different programs.

12. What are Lists and Tuples? What is the Key Difference Between the Two?



```python
my_list = [1, 2, 3]
my_list.append(4)
print(my_list)  # Output: [1, 2, 3, 4]

```


```python
my_tuple = (1, 2, 3)
# my_tuple[0] = 10  # This will raise a TypeError because tuples are immutable

```

13. What is an Interpreted Language & Dynamically Typed Language? Write 5 Differences Between Them
Interpreted Language: A type of programming language where the code is executed line by line by an interpreter rather than being compiled into machine code.

Dynamically Typed Language: A language where variable types are determined at runtime, and you do not need to declare the type of a variable explicitly.

Differences:

Compilation: Interpreted languages are executed by an interpreter, while compiled languages are converted into machine code by a compiler.
Error Detection: In interpreted languages, errors are detected at runtime, while in compiled languages, errors are detected during compilation.
Performance: Interpreted languages are generally slower than compiled languages because each instruction is translated at runtime.
Flexibility: Dynamically typed languages allow variables to change types at runtime, while statically typed languages require variables to have a fixed type.
Debugging: Interpreted languages are often easier to debug because of their line-by-line execution, while compiled languages require recompilation to reflect changes.


```python
14. What are Dict and List Comprehensions?

```


```python
14. What are Dict and List Comprehensions
```


```python
squares = {x: x**2 for x in range(5)}
print(squares)  # Output: {0: 0, 1: 1, 2: 4, 3: 9, 4: 16}

```


```python
squares = [x**2 for x in range(5)]
print(squares)  # Output: [0, 1, 4, 9, 16]

```

15. What are Decorators in Python? Explain with an Example. Write Down Its Use Cases


```python
def my_decorator(func):
    def wrapper():
        print("Something is happening before the function is called.")
        func()
        print("Something is happening after the function is called.")
    return wrapper

@my_decorator
def say_hello():
    print("Hello!")

say_hello()
# Output:
# Something is happening before the function is called.
# Hello!
# Something is happening after the function is called.

```


```python
def my_decorator(func):
    def wrapper():
        print("Something is happening before the function is called.")
        func()
        print("Something is happening after the function is called.")
    return wrapper

@my_decorator
def say_hello():
    print("Hello!")

say_hello()
# Output:
# Something is happening before the function is called.
# Hello!
# Something is happening after the function is called.

```

16. How is Memory Managed in Python?
Memory Management: Python uses an automatic memory management system that includes a private heap containing all Python objects and data structures. Memory allocation and deallocation are managed by Python's garbage collector, which uses reference counting and a cyclic garbage collector to reclaim memory.


```python
17. What is Lambda in Python? Why is it Used?
```


```python
17. What is Lambda in Python? Why is it Used
```


```python
add = lambda x, y: x + y
print(add(5, 3))  # Output: 8

```


```python
add = lambda x, y: x + y
print(add(5, 3))  # Output: 8

```

18. Explain split() and join() functions in Python.


```python
text = "Hello World"
words = text.split()
print(words)  # Output: ['Hello', 'World']

```


```python
words = ['Hello', 'World']
sentence = ' '.join(words)
print(sentence)  # Output: Hello World

```

19. What are iterators, iterable & generators in Python?


```python
my_list = [1, 2, 3]
for i in my_list:
    print(i)

```


```python
my_iter = iter([1, 2, 3])
print(next(my_iter))  # Output: 1

```


```python
def my_gen():
    yield 1
    yield 2
    yield 3

for value in my_gen():
    print(value)

```

20. What is the difference between xrange and range in Python?
range(): Returns a list in Python 2 and an iterator in Python 3.
xrange(): Used in Python 2 to return an iterator, similar to the range() function in Python 3.
Note: xrange() was removed in Python 3, where range() now behaves like xrange().

21. Pillars of OOPs
Encapsulation: Bundling the data and the methods that operate on the data within one unit, e.g., a class.
Inheritance: The mechanism of deriving a new class from an existing class.
Polymorphism: The ability to define a function or method that can take on different forms.
Abstraction: Hiding the complex implementation details and showing only the necessary features of an object.

22. How will you check if a class is a child of another class?


```python
class Parent:
    pass

class Child(Parent):
    pass

print(issubclass(Child, Parent))  # Output: True

```

23. How does inheritance work in Python? Explain all types of inheritance with an example.


```python
class Parent:
    pass

class Child(Parent):
    pass

```

Multiple Inheritance: A class inherits from more than one base class.




```python
class Parent1:
    pass

class Parent2:
    pass

class Child(Parent1, Parent2):
    pass

```

24. What is encapsulation? Explain it with an example.


```python
class MyClass:
    def __init__(self, value):
        self.__hidden_var = value  # Private attribute

    def get_value(self):
        return self.__hidden_var

obj = MyClass(42)
print(obj.get_value())  # Output: 42

```

25. What is polymorphism? Explain it with an example.


```python
class Animal:
    def speak(self):
        pass

class Dog(Animal):
    def speak(self):
        return "Woof!"

class Cat(Animal):
    def speak(self):
        return "Meow!"

animals = [Dog(), Cat]
for animal in animals:
    print(animal.speak()) 

```

Question 1.2: Identify Invalid Identifiers
Let's examine each identifier to determine if it's valid:

a) Serial_no.

Invalid: Identifiers should not end with a period (.). The period is typically used for accessing attributes and methods, not as part of an identifier.
b) 1st_Room

Invalid: Identifiers cannot start with a number. Python identifiers must start with a letter (a-z, A-Z) or an underscore (_).
c) Hundred$

Invalid: The dollar sign ($) is not allowed in Python identifiers. Identifiers can only contain letters, numbers, and underscores.
d) Total_Marks

Valid: This is a valid identifier. It starts with a letter and contains an underscore, which is allowed.
e) total-Marks

Invalid: The hyphen (-) is not allowed in Python identifiers. It’s considered a subtraction operator.
f) Total Marks

Invalid: Spaces are not allowed in Python identifiers. Identifiers should be continuous without spaces.
g) True

Invalid: True is a reserved keyword in Python, used as a Boolean value. Identifiers cannot use reserved keywords.
h) _Percentag

Valid: This is a valid identifier. It starts with an underscore and contains only letters, which is allowed.

Question 1.3: Operations on a List


```python
name = ["Mohan", "dash", "karam", "chandra","gandhi","Bapu"]

```


```python
name.insert(0, "freedom_fighter")
print(name)

```


```python
name.insert(0, "freedom_fighter")
print(name)

```


```python
name = ["freedomFighter","Bapuji","MOhan" "dash", "karam", "chandra","gandhi"]
length1 = len((name[-len(name)+1:-1:2]))
length2 = len((name[-len(name)+1:-1]))
print(length1 + length2)

```

Question 1.5: Tuple Operations


```python
tuple1 = (10, 20, "Apple", 3.4, 'a', ["master", "ji"], ("sita", "geeta", 22), [{"roll_no": 1}, {"name": "Navneet"}])

```


```python
8

```


```python
roll_no = tuple1[-1][0]["roll_no"]
print(roll_no)

```


```python
1

```


```python
value = tuple1[-3][2]
print(value)

```

Question 1.6: Traffic Signal Program


```python
signal = input("Enter the signal color (RED/Yellow/Green): ")

if signal.lower() == "red":
    print("Stop")
elif signal.lower() == "yellow":
    print("Stay")
elif signal.lower() == "green":
    print("Go")
else:
    print("Invalid color")

```

Question 1.7: Simple Calculator


```python
def calculator():
    operation = input("Choose an operation (+, -, *, /): ")
    num1 = float(input("Enter first number: "))
    num2 = float(input("Enter second number: "))

    if operation == "+":
        print(f"The result is: {num1 + num2}")
    elif operation == "-":
        print(f"The result is: {num1 - num2}")
    elif operation == "*":
        print(f"The result is: {num1 * num2}")
    elif operation == "/":
        if num2 != 0:
            print(f"The result is: {num1 / num2}")
        else:
            print("Error! Division by zero.")
    else:
        print("Invalid operation")

calculator()

```

Question 1.8: Find the Largest of Three Numbers using Ternary Operator


```python
a = 10
b = 20
c = 15

largest = a if (a > b and a > c) else b if (b > c) else c
print(f"The largest number is: {largest}")

```


```python
a = 10
b = 20
c = 15

largest = a if (a > b and a > c) else b if (b > c) else c
print(f"The largest number is: {largest}")

```

Question 1.9: Find Factors of a Number using While Loop


```python
num = int(input("Enter a number: "))
i = 1
print(f"Factors of {num} are:", end=" ")

while i <= num:
    if num % i == 0:
        print(i, end=" ")
    i += 1

```

Question 1.10: Sum of Positive Numbers Until a Negative Number is Entered


```python
sum = 0
while True:
    num = int(input("Enter a positive number (or a negative number to stop): "))
    if num < 0:
        break
    sum += num

print(f"The sum of the positive numbers is: {sum}")

```


```python
Question 1.11: Prime Numbers Between 2 to 100
```


```python
for num in range(2, 101):
    is_prime = True
    for i in range(2, int(num ** 0.5) + 1):
        if num % i == 0:
            is_prime = False
            break
    if is_prime:
        print(num, end=" ")

```


```python
Question 1.12: Calculate and Display Student Marks
```

1.13. Write a program for VIBGYOR Spectrum based on their Wavelength using.
 Wavelength Range


```python
def determine_vibgyor_color(wavelength):
    if 380 <= wavelength < 450:
        return "Violet"
    elif 450 <= wavelength < 485:
        return "Indigo"
    elif 485 <= wavelength < 500:
        return "Blue"
    elif 500 <= wavelength < 570:
        return "Green"
    elif 570 <= wavelength < 590:
        return "Yellow"
    elif 590 <= wavelength < 620:
        return "Orange"
    elif 620 <= wavelength <= 750:
        return "Red"
    else:
        return "Wavelength out of VIBGYOR spectrum range"

# Get input from the user
wavelength = float(input("Enter the wavelength in nanometers (nm): "))

# Determine and display the color
color = determine_vibgyor_color(wavelength)
print(f"The color corresponding to {wavelength} nm is: {color}")

```

    Enter the wavelength in nanometers (nm): 6666
    The color corresponding to 6666.0 nm is: Wavelength out of VIBGYOR spectrum range
    

 1.14.Consider the gravitational interactions between the Earth, Moon, and Sun in our solar system. 
Given:
 mass_earth = 5.972e24  # Mass of Earth in kilograms
 mass_moon = 7.34767309e22  # Mass of Moon in kilograms
 mass_sun = 1.989e30  # Mass of Sun in kilograms
 distance_earth_sun = 1.496e11  # Average distance between Earth and Sun in meters
 distance_moon_earth = 3.844e8  # Average distance between Moon and Earth in meters
 Calculate the gravitational force between the Earth and the Sun
 Calculate the gravitational force between the Moon and the Earth
 Compare the calculated forces to determine which gravitational force is stronger
 Explain which celestial body (Earth or Moon) is more attracted to the other based on the comparison

Sure! Let's break this down into manageable parts. Here’s a summary of how to approach each task:

1. Gravitational Force Calculations
To calculate the gravitational forces, you can use Newton's Law of Universal Gravitation:

𝐹
=
𝐺
⋅
𝑚
1
⋅
𝑚
2
𝑟
2
F= 
r 
2
 
G⋅m 
1
​
 ⋅m 
2
​
 
​
 

where 
𝐺
G is the gravitational constant (
6.67430
×
1
0
−
11
 
m
3
kg
−
1
s
−
2
6.67430×10 
−11
 m 
3
 kg 
−1
 s 
−2
 ).

Python code to calculate gravitational forces:


```python
# Constants
G = 6.67430e-11  # Gravitational constant in m^3 kg^-1 s^-2

# Masses in kg
mass_earth = 5.972e24
mass_moon = 7.34767309e22
mass_sun = 1.989e30

# Distances in meters
distance_earth_sun = 1.496e11
distance_moon_earth = 3.844e8

# Gravitational Force calculations
force_earth_sun = G * mass_earth * mass_sun / (distance_earth_sun ** 2)
force_moon_earth = G * mass_moon * mass_earth / (distance_moon_earth ** 2)

print(f"Gravitational Force between Earth and Sun: {force_earth_sun:.2e} N")
print(f"Gravitational Force between Moon and Earth: {force_moon_earth:.2e} N")

# Comparison
if force_earth_sun > force_moon_earth:
    print("The gravitational force between Earth and the Sun is stronger.")
else:
    print("The gravitational force between Moon and Earth is stronger.")

```

    Gravitational Force between Earth and Sun: 3.54e+22 N
    Gravitational Force between Moon and Earth: 1.98e+20 N
    The gravitational force between Earth and the Sun is stronger.
    

2. Design and implement a Python program for managing student information using object-oriented 
principles. Create a class called `Student` with encapsulated attributes for name, age, and roll number. 
Implement getter and setter methods for these attributes. Additionally, provide methods to display student 
information and update student details.
 Tasks
 Define the `Student` class with encapsulated attributes
 Implement getter and setter methods for the attributes
 Write methods to display student information and update details
 Create instances of the `Student` class and test the implemented functionality


```python
class Student:
    def __init__(self, name, age, roll_number):
        self.__name = name
        self.__age = age
        self.__roll_number = roll_number

    # Getter methods
    def get_name(self):
        return self.__name

    def get_age(self):
        return self.__age

    def get_roll_number(self):
        return self.__roll_number

    # Setter methods
    def set_name(self, name):
        self.__name = name

    def set_age(self, age):
        self.__age = age

    def set_roll_number(self, roll_number):
        self.__roll_number = roll_number

    # Method to display student information
    def display_info(self):
        return f"Name: {self.__name}, Age: {self.__age}, Roll Number: {self.__roll_number}"

    # Method to update student details
    def update_details(self, name=None, age=None, roll_number=None):
        if name:
            self.set_name(name)
        if age:
            self.set_age(age)
        if roll_number:
            self.set_roll_number(roll_number)

# Testing
student1 = Student("John Doe", 20, "A123")
print(student1.display_info())
student1.update_details(age=21)
print(student1.display_info())

```

    Name: John Doe, Age: 20, Roll Number: A123
    Name: John Doe, Age: 21, Roll Number: A123
    

3.Develop a Python program for managing library resources efficiently. Design a class named `LibraryBook` 
with attributes like book name, author, and availability status. Implement methods for borrowing and 
returning books while ensuring proper encapsulation of attributes.
 Tasks
 1. Create the `LibraryBook` class with encapsulated attributes
 2. Implement methods for borrowing and returning books
 3. Ensure proper encapsulation to protect book details
 4. Test the borrowing and returning functionality with sample data


```python
class LibraryBook:
    def __init__(self, book_name, author, available=True):
        self.__book_name = book_name
        self.__author = author
        self.__available = available

    # Getter methods
    def get_book_name(self):
        return self.__book_name

    def get_author(self):
        return self.__author

    def is_available(self):
        return self.__available

    # Method to borrow a book
    def borrow_book(self):
        if self.__available:
            self.__available = False
            return "Book borrowed successfully."
        else:
            return "Book is not available."

    # Method to return a book
    def return_book(self):
        if not self.__available:
            self.__available = True
            return "Book returned successfully."
        else:
            return "Book was not borrowed."

# Testing
book1 = LibraryBook("1984", "George Orwell")
print(book1.borrow_book())
print(book1.return_book())

```

    Book borrowed successfully.
    Book returned successfully.
    

 4.Create a simple banking system using object-oriented concepts in Python. Design classes representing 
different types of bank accounts such as savings and checking. Implement methods for deposit, withdraw, 
and balance inquiry. Utilize inheritance to manage different account types efficiently.
 Tasks
 1. Define base class(es) for bank accounts with common attributes and methods
 2. Implement subclasses for specific account types (e.g., SavingsAccount, CheckingAccount)
 3. Provide methods for deposit, withdraw, and balance inquiry in each subclass
 4. Test the banking system by creating instances of different account types and performing transactions

5.Write a Python program that models different animals and their sounds. Design a base class called 
`Animal` with a method `make_sound()`. Create subclasses like `Dog` and `Cat` that override the 
`make_sound()` method to produce appropriate sounds.
 Tasks
 1. Define the `Animal` class with a method `make_sound()`
 2. Create subclasses `Dog` and `Cat` that override the `make_sound()` method
 3. Implement the sound generation logic for each subclass
 4. Test the program by creating instances of `Dog` and `Cat` and calling the `make_sound()` method.



```python
class Animal:
    def make_sound(self):
        pass

class Dog(Animal):
    def make_sound(self):
        return "Woof!"

class Cat(Animal):
    def make_sound(self):
        return "Meow!"

# Testing
dog = Dog()
cat = Cat()
print(dog.make_sound())
print(cat.make_sound())

```

    Woof!
    Meow!
    

6.Write a code for Restaurant Management System Using OOPS
 Create a MenuItem class that has attributes such as name, description, price, and category
 Implement methods to add a new menu item, update menu item information, and remove a menu item 
from the menu
 Use encapsulation to hide the menu item's unique identification number
 Inherit from the MenuItem class to create a FoodItem class and a BeverageItem class, each with their own 
specific attributes and methods


```python
class MenuItem:
    def __init__(self, name, description, price, category):
        self.__name = name
        self.__description = description
        self.__price = price
        self.__category = category

    # Getter and Setter methods
    def get_name(self):
        return self.__name

    def set_name(self, name):
        self.__name = name

    def get_description(self):
        return self.__description

    def set_description(self, description):
        self.__description = description

    def get_price(self):
        return self.__price

    def set_price(self, price):
        self.__price = price

    def get_category(self):
        return self.__category

    def set_category(self, category):
        self.__category = category

    # Display method
    def display_info(self):
        return f"Name: {self.__name}, Description: {self.__description}, Price: {self.__price}, Category: {self.__category}"

    # Update method
    def update_item(self, name=None, description=None, price=None, category=None):
        if name:
            self.set_name(name)
        if description:
            self.set_description(description)
        if price:
            self.set_price(price)
        if category:
            self.set_category(category)

# Testing
item = MenuItem("Burger", "Beef burger with cheese", 5.99, "Food")
print(item.display_info())
item.update_item(price=6.49)
print(item.display_info())

```

    Name: Burger, Description: Beef burger with cheese, Price: 5.99, Category: Food
    Name: Burger, Description: Beef burger with cheese, Price: 6.49, Category: Food
    

 7.Write a code for  Hotel Management System using OOPS 
Create a Room class that has attributes such as room number, room type, rate, and availability (private)
 Implement methods to book a room, check in a guest, and check out a guest
 Use encapsulation to hide the room's unique identification number
 Inherit from the Room class to create a SuiteRoom class and a StandardRoom class, each with their own 
specific attributes and methods


```python
class Room:
    def __init__(self, room_number, room_type, rate):
        self.__room_number = room_number
        self.__room_type = room_type
        self.__rate = rate
        self.__availability = True

    def book_room(self):
        if self.__availability:
            self.__availability = False
            return "Room booked successfully."
        else:
            return "Room is not available."

    def check_in(self, guest_name):
        if not self.__availability:
            return f"Checked in guest {guest_name}."
        else:
            return "Room is available, cannot check-in."

    def check_out(self):
        if not self.__availability:
            self.__availability = True
            return "Checked out successfully."
        else:
            return "Room is not occupied."

class SuiteRoom(Room):
    def __init__(self, room_number, rate, additional_services):
        super().__init__(room_number, "Suite", rate)
        self.__additional_services = additional_services

    def display_services(self):
        return f"Additional Services: {self.__additional_services}"

class StandardRoom(Room):
    def __init__(self, room_number, rate):
        super().__init__(room_number, "Standard", rate)

# Testing
suite = SuiteRoom(101, 200, "Spa, Breakfast")
print(suite.book_room())
print(suite.display_services())
standard = StandardRoom(102, 100)
print(standard.check_in("Alice"))
print(standard.check_out())

```

    Room booked successfully.
    Additional Services: Spa, Breakfast
    Room is available, cannot check-in.
    Room is not occupied.
    

 8.Write a code for  Fitness Club Management System using OOPS
 Create a Member class that has attributes such as name, age, membership type, and membership status 
(private)
 Implement methods to register a new member, renew a membership, and cancel a membership
 Use encapsulation to hide the member's unique identification number
 Inherit from the Member class to create a FamilyMember class and an IndividualMember class, each with 
their own specific attributes and methods


```python
class Member:
    def __init__(self, name, age, membership_type):
        self.__name = name
        self.__age = age
        self.__membership_type = membership_type
        self.__status = "Active"

    def register_member(self):
        self.__status = "Active"
        return f"Member {self.__name} registered successfully."

    def renew_membership(self):
        self.__status = "Renewed"
        return f"Membership renewed for {self.__name}."

    def cancel_membership(self):
        self.__status = "Cancelled"
        return f"Membership cancelled for {self.__name}."

class FamilyMember(Member):
    def __init__(self, name, age, membership_type, family_members):
        super().__init__(name, age, membership_type)
        self.__family_members = family_members

    def display_family_members(self):
        return f"Family Members: {self.__family_members}"

class IndividualMember(Member):
    pass

# Testing
family_member = FamilyMember("John", 30, "Family", ["Jane", "Joe"])
print(family_member.register_member())
print(family_member.display_family_members())
individual_member = IndividualMember("Alice", 25, "Individual")
print(individual_member.renew_membership())

```

    Member John registered successfully.
    Family Members: ['Jane', 'Joe']
    Membership renewed for Alice.
    

 9.Write a code for  Event Management System using OOPS
 Create an Event class that has attributes such as name, date, time, location, and list of attendees (private)
 Implement methods to create a new event, add or remove attendees, and get the total number of 
attendees
 Use encapsulation to hide the event's unique identification number
 Inherit from the Event class to create a PrivateEvent class and a PublicEvent class, each with their own 
specific attributes and methods


```python
class Event:
    def __init__(self, name, date, time, location):
        self.__name = name
        self.__date = date
        self.__time = time
        self.__location = location
        self.__attendees = []

    def create_event(self):
        return f"Event {self.__name} created."

    def add_attendee(self, attendee):
        self.__attendees.append(attendee)
        return f"{attendee} added to the event."

    def remove_attendee(self, attendee):
        if attendee in self.__attendees:
            self.__attendees.remove(attendee)
            return f"{attendee} removed from the event."
        else:
            return f"{attendee} not found."

    def total_attendees(self):
        return len(self.__attendees)

class PrivateEvent(Event):
    def __init__(self, name, date, time, location, invitation_only):
        super().__init__(name, date, time, location)
        self.__invitation_only = invitation_only

class PublicEvent(Event):
    def __init__(self, name, date, time, location, ticket_price):
        super().__init__(name, date, time, location)
        self.__ticket_price = ticket_price

# Testing
event = PublicEvent("Music Festival", "2024-09-15", "18:00", "Central Park", 50)
print(event.create_event())
print(event.add_attendee("Alice"))
print(event.total_attendees())

```

    Event Music Festival created.
    Alice added to the event.
    1
    

 10.Write a code for Airline Reservation System using OOPS
 Create a Flight class that has attributes such as flight number, departure and arrival airports, departure and 
arrival times, and available seats (private)
 Implement methods to book a seat, cancel a reservation, and get the remaining available seats
 Use encapsulation to hide the flight's unique identification number
 Inherit from the Flight class to create a DomesticFlight class and an InternationalFlight class, each with their 
own specific attributes and methods


```python
class Flight:
    def __init__(self, flight_number, departure, arrival, departure_time, arrival_time, available_seats):
        self.__flight_number = flight_number
        self.__departure = departure
        self.__arrival = arrival
        self.__departure_time = departure_time
        self.__arrival_time = arrival_time
        self.__available_seats = available_seats

    def book_seat(self):
        if self.__available_seats > 0:
            self.__available_seats -= 1
            return f"Seat booked. Remaining seats: {self.__available_seats}."
        else:
            return "No seats available."

    def cancel_reservation(self):
        self.__available_seats += 1
        return f"Reservation canceled. Remaining seats: {self.__available_seats}."

    def get_available_seats(self):
        return self.__available_seats

class DomesticFlight(Flight):
    pass

class InternationalFlight(Flight):
    def __init__(self, flight_number, departure, arrival, departure_time, arrival_time, available_seats, visa_required):
        super().__init__(flight_number, departure, arrival, departure_time, arrival_time, available_seats)
        self.__visa_required = visa_required

# Testing
domestic_flight = DomesticFlight("D123", "NYC", "LA", "09:00", "12:00", 50)
print(domestic_flight.book_seat())
international_flight = InternationalFlight("I456", "NYC", "London", "18:00", "06:00", 20, True)
print(international_flight.get_available_seats())

```

    Seat booked. Remaining seats: 49.
    20
    

11. Define a Python module named constants.py containing constants like pi and the speed of light.


```python
# constants.py
PI = 3.141592653589793
SPEED_OF_LIGHT = 299792458  # meters per second

```

12. Write a Python module named calculator.py containing functions for addition, subtraction, 
multiplication, and division.


```python
# calculator.py
def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

def divide(a, b):
    if b != 0:
        return a / b
    else:
        return "Division by zero is not allowed."

```

 13. Implement a Python package structure for a project named ecommerce, containing modules for product 
management and order processing.
 14. Implement a Python module named string_utils.py containing functions for string manipulation, such as 
reversing and capitalizing strings.
 15. Write a Python module named file_operations.py with functions for reading, writing, and appending 
data to a file.
 16. Write a Python program to create a text file named "employees.txt" and write the details of employees, 
including their name, age, and salary, into the file.
 17. Develop a Python script that opens an existing text file named "inventory.txt" in read mode and displays 
the contents of the file line by line.
 18. Create a Python script that reads a text file named "expenses.txt" and calculates the total amount spent 
on various expenses listed in the file.
 19. Create a Python program that reads a text file named "paragraph.txt" and counts the occurrences of 
each word in the paragraph, displaying the results in alphabetical order.
 21. What do you mean by skewness.Explain its types.Use graph to show.
 20. What do you mean by Measure of Central Tendency and Measures of Dispersion .How it can be 
calculated.
 22. Explain PROBABILITY MASS FUNCTION (PMF) and PROBABILITY DENSITY FUNCTION (PDF). and what is the 
difference between them?
 23. What is correlation. Explain its type in details.what are the  methods of determining correlatio


```python
# product_management.py
class Product:
    def __init__(self, product_id, name, price):
        self.product_id = product_id
        self.name = name
        self.price = price

    def display_product(self):
        return f"ID: {self.product_id}, Name: {self.name}, Price: {self.price}"

```


```python
# order_processing.py
class Order:
    def __init__(self, order_id, product_list):
        self.order_id = order_id
        self.product_list = product_list

    def total_amount(self):
        return sum(product.price for product in self.product_list)

```


```python
# string_utils.py
def reverse_string(s):
    return s[::-1]

def capitalize_string(s):
    return s.upper()

```


```python
# string_utils.py
def reverse_string(s):
    return s[::-1]

def capitalize_string(s):
    return s.upper()

```


```python
# string_utils.py
def reverse_string(s):
    return s[::-1]

def capitalize_string(s):
    return s.upper()

```


```python
# file_operations.py
def read_file(filename):
    with open(filename, 'r') as file:
        return file.read()

def write_file(filename, content):
    with open(filename, 'w') as file:
        file.write(content)

def append_to_file(filename, content):
    with open(filename, 'a') as file:
        file.write(content)

```


```python
# Creating and writing to employees.txt
employees = [
    {"name": "John Doe", "age": 30, "salary": 50000},
    {"name": "Jane Smith", "age": 25, "salary": 55000},
]

with open("employees.txt", 'w') as file:
    for emp in employees:
        file.write(f"Name: {emp['name']}, Age: {emp['age']}, Salary: {emp['salary']}\n")

```


```python
import numpy as np
import scipy.stats as stats

data = [1, 2, 2, 3, 4, 5, 6, 7, 8, 9]

mean = np.mean(data)
median = np.median(data)
mode = stats.mode(data)[0][0]
variance = np.var(data)
std_deviation = np.std(data)

print(f"Mean: {mean}")
print(f"Median: {median}")
print(f"Mode: {mode}")
print(f"Variance: {variance}")
print(f"Standard Deviation: {std_deviation}")

```

    Mean: 4.7
    Median: 4.5
    Mode: 2
    Variance: 6.81
    Standard Deviation: 2.6095976701399777
    

    C:\Users\malik\AppData\Local\Temp\ipykernel_17068\2268715605.py:8: FutureWarning: Unlike other reduction functions (e.g. `skew`, `kurtosis`), the default behavior of `mode` typically preserves the axis it acts along. In SciPy 1.11.0, this behavior will change: the default value of `keepdims` will become False, the `axis` over which the statistic is taken will be eliminated, and the value None will no longer be accepted. Set `keepdims` to True or False to avoid this warning.
      mode = stats.mode(data)[0][0]
    


```python
24. Calculate coefficient of correlation between the marks obtained by 10 students in Accountancy and 
statistics:
```

25. Differences Between Correlation and Regression
Purpose:

Correlation: Measures the strength and direction of the linear relationship between two variables.
Regression: Predicts the value of the dependent variable based on the value of the independent variable(s).
Dependency:

Correlation: Does not imply causation or dependency between variables. Both variables are treated symmetrically.
Regression: Establishes a dependent relationship where one variable (dependent) is predicted based on one or more other variables (independent).
Equation:

Correlation: Does not provide an equation or line; it provides a single value (correlation coefficient) ranging between -1 and +1.
Regression: Provides an equation representing the relationship, typically of the form 
𝑦
=
𝑚
𝑥
+
𝑐
y=mx+c in linear regression.
Units:

Correlation: The correlation coefficient is unitless, which means it does not depend on the units of the variables.
Regression: The regression coefficients have units and depend on the units of the dependent and independent variables.
26. Most Likely Price in Delhi
Given:

Price in Agra = Rs. 70
Coefficient of correlation 
𝑟
=
0.8
r=0.8
Let the means be 
𝑋
‾
X
  (Agra) and 
𝑌
‾
Y
  (Delhi)
Let the standard deviations be 
𝜎
𝑋
σ 
X
​
  and 
𝜎
𝑌
σ 
Y
​
 
We assume the linear relationship: 
𝑌
=
𝑎
+
𝑏
𝑋
Y=a+bX

The formula for predicting the value is: 
𝑌
=
𝑌
‾
+
𝑟
(
𝜎
𝑌
𝜎
𝑋
)
(
𝑋
−
𝑋
‾
)
Y= 
Y
 +r( 
σ 
X
​
 
σ 
Y
​
 
​
 )(X− 
X
 )

But to solve this, we need the means and standard deviations of the prices at both locations, which aren't provided. If you have this data, you can plug it into the formula.

27. Analysis of Correlation Data
Given:

Variance of 
𝑥
=
9
x=9, so 
𝜎
𝑥
=
3
σ 
x
​
 =3
Regression equations:
8
𝑥
−
10
𝑦
=
−
66
8x−10y=−66
40
𝑥
−
18
𝑦
=
214
40x−18y=214
(a) Mean Values of 
𝑥
x and 
𝑦
y:
First, rearrange the regression equations to solve for 
𝑥
x and 
𝑦
y:

8
𝑥
=
10
𝑦
−
66
⇒
𝑥
=
10
8
𝑦
−
66
8
⇒
𝑥
=
1.25
𝑦
−
8.25
8x=10y−66⇒x= 
8
10
​
 y− 
8
66
​
 ⇒x=1.25y−8.25
40
𝑥
=
18
𝑦
+
214
⇒
𝑥
=
18
40
𝑦
+
214
40
⇒
𝑥
=
0.45
𝑦
+
5.35
40x=18y+214⇒x= 
40
18
​
 y+ 
40
214
​
 ⇒x=0.45y+5.35
Equating both expressions for 
𝑥
x:

1.25
𝑦
−
8.25
=
0.45
𝑦
+
5.35
1.25y−8.25=0.45y+5.35 
0.8
𝑦
=
13.6
0.8y=13.6 
𝑦
=
17
y=17

Now, substitute 
𝑦
=
17
y=17 back into either equation to find 
𝑥
x:

𝑥
=
1.25
(
17
)
−
8.25
=
21.25
−
8.25
=
13
x=1.25(17)−8.25=21.25−8.25=13

So, 
𝑥
‾
=
13
x
 =13 and 
𝑦
‾
=
17
y
​
 =17.

(b) Coefficient of Correlation 
𝑟
r:
The coefficient of correlation is given by: 
𝑟
=
𝑏
𝑦
𝑥
×
𝑏
𝑥
𝑦
r= 
b 
yx
​
 ×b 
xy
​
 
​
 

From the regression equations: 
𝑏
𝑦
𝑥
=
Coefficient of 
𝑦
 in the first equation
Coefficient of 
𝑥
=
8
10
=
0.8
b 
yx
​
 = 
Coefficient of x
Coefficient of y in the first equation
​
 = 
10
8
​
 =0.8

𝑏
𝑥
𝑦
=
Coefficient of 
𝑥
 in the second equation
Coefficient of 
𝑦
=
18
40
=
0.45
b 
xy
​
 = 
Coefficient of y
Coefficient of x in the second equation
​
 = 
40
18
​
 =0.45

Therefore: 
𝑟
=
0.8
×
0.45
=
0.36
=
0.6
r= 
0.8×0.45
​
 = 
0.36
​
 =0.6

(c) Standard Deviation 
𝜎
𝑦
σ 
y
​
 :
Using the relation: 
𝑏
𝑦
𝑥
=
𝑟
(
𝜎
𝑦
𝜎
𝑥
)
b 
yx
​
 =r( 
σ 
x
​
 
σ 
y
​
 
​
 )

Substituting the known values: 
0.8
=
0.6
×
𝜎
𝑦
3
0.8=0.6× 
3
σ 
y
​
 
​
 

Solving for 
𝜎
𝑦
σ 
y
​
 : 
𝜎
𝑦
=
0.8
×
3
0.6
=
4
σ 
y
​
 = 
0.6
0.8×3
​
 =4

28. Normal Distribution and Its Assumptions
Normal Distribution:

A normal distribution is a bell-shaped probability distribution that is symmetric around the mean. It describes how the values of a variable are distributed.
The total area under the curve is 1, and it is characterized by two parameters: the mean (µ) and the standard deviation (σ).
Four Assumptions:

Symmetry: The distribution is symmetric about the mean.
Unimodality: There is only one peak (mode) in the distribution.
Asymptotic: The tails of the distribution approach the horizontal axis but never touch it.
Mean = Median = Mode: In a perfectly normal distribution, the mean, median, and mode are equal.
29. Characteristics of Normal Distribution Curve
Bell-Shaped: The curve is bell-shaped and symmetric around the mean.
Mean, Median, and Mode: In a normal distribution, these three are all equal and located at the center of the distribution.
Area Under the Curve: The total area under the curve is 1.
Empirical Rule: Approximately 68.27% of data lies within 1 standard deviation of the mean, 95.45% within 2 standard deviations, and 99.73% within 3 standard deviations.
Asymptotic Nature: The tails of the curve approach the x-axis but never touch it.
30. Correct Statements About Normal Distribution Curve
All the options provided are correct about the normal distribution curve.

31. Percentage of Items in a Normal Distribution
Given:

Mean 
𝜇
=
60
μ=60
Standard deviation 
𝜎
=
10
σ=10
We can use the Z-score formula to solve the following:

𝑍
=
𝑋
−
𝜇
𝜎
Z= 
σ
X−μ
​
 

(i) Between 60 and 72:
𝑍
1
=
60
−
60
10
=
0
Z 
1
​
 = 
10
60−60
​
 =0 
𝑍
2
=
72
−
60
10
=
1.2
Z 
2
​
 = 
10
72−60
​
 =1.2

Using the standard normal distribution table, 
𝑍
=
1.2
Z=1.2 corresponds to an area of 0.3849.

Thus, the area between 60 and 72 is 
0.3849
−
0.5
=
0.3849
0.3849−0.5=0.3849.

So, approximately 38.49% of items are between 60 and 72.

(ii) Between 50 and 60:
𝑍
1
=
50
−
60
10
=
−
1
Z 
1
​
 = 
10
50−60
​
 =−1 
𝑍
2
=
60
−
60
10
=
0
Z 
2
​
 = 
10
60−60
​
 =0

Using the standard normal distribution table, 
𝑍
=
−
1
Z=−1 corresponds to an area of 0.1587.

Thus, the area between 50 and 60 is 
0.5
−
0.1587
=
0.3413
0.5−0.1587=0.3413.

So, approximately 34.13% of items are between 50 and 60.

(iii) Beyond 72:
Beyond 72 corresponds to an area of 
1
−
0.8849
=
0.1151
1−0.8849=0.1151, so approximately 11.51% of items are beyond 72.

(iv) Between 70 and 80:
𝑍
1
=
70
−
60
10
=
1
Z 
1
​
 = 
10
70−60
​
 =1 
𝑍
2
=
80
−
60
10
=
2
Z 
2
​
 = 
10
80−60
​
 =2

Using the Z-table, the area between 
𝑍
1
=
1
Z 
1
​
 =1 and 
𝑍
2
=
2
Z 
2
​
 =2 is 
0.4772
−
0.3413
=
0.1359
0.4772−0.3413=0.1359.

So, approximately 13.59% of items are between 70 and 80.

32. Normal Distribution and Student Marks
Given:

Mean 
𝜇
=
49
μ=49
Standard deviation 
𝜎
=
6
σ=6
(a) More than 55 marks:
𝑍
=
55
−
49
6
=
1
Z= 
6
55−49
​
 =1

Using the Z-table, 
𝑍
=
1
Z=1 corresponds to an area of 0.8413.

Thus, the area beyond 55 marks is 
1
−
0.8413
=
0.1587
1−0.8413=0.1587, so approximately 15.87% of students scored more than 55 marks.

(b) More than 70 marks:
𝑍
=
70
−
49
6
=
3.5
Z= 
6
70−49
​
 =3.5

Using the Z-table, 
𝑍
=
3.5
Z=3.5 corresponds to an area close to 1. This means very few









If the height of 500 students are normally distributed with mean 65 inch and standard deviation 5 inch. How many students have height : a) greater than 70 inch. b) between 60 and 70 inch.
What is the statistical hypothesis? Explain the errors in hypothesis testing.b)Explain the Sample. What are Large Samples & Small Samples? 35.A random sample of size 25 from a population gives the sample standard derivation to be 9.0. Test the hypothesis that the population standard derivation is 10.5. Hint(Use chi-square distribution). 37.100 students of a PW IOI obtained the following grades in Data Science paper : Grade :[A, B, C, D, E] Total Frequency :[15, 17, 30, 22, 16, 100] Using the χ 2 test , examine the hypothesis that the distribution of grades is uniform

I'd be happy to help you with these statistics questions.

33.

Let's break down the problem step by step:

We have a normal distribution of heights with a mean of 65 inches and a standard deviation of 5 inches. We want to find the number of students with heights:

a) greater than 70 inches

To do this, we need to find the z-score corresponding to 70 inches:

z = (70 - 65) / 5 = 1

Using a standard normal distribution table (Z-table), we find that the area to the right of z = 1 is approximately 0.1587. Since there are 500 students, we multiply this area by 500:

Number of students with height > 70 inches ≈ 500 * 0.1587 ≈ 79.35 ≈ 79 students

b) between 60 and 70 inches

To find the number of students with heights between 60 and 70 inches, we need to find the z-scores corresponding to 60 and 70 inches:

z_1 = (60 - 65) / 5 = -1 z_2 = (70 - 65) / 5 = 1

Using the Z-table, we find the areas to the left of z_1 and to the right of z_2:

Area to the left of z_1 ≈ 0.8413 Area to the right of z_2 ≈ 0.1587

The area between 60 and 70 inches is the difference between these two areas:

Area between 60 and 70 inches ≈ 0.8413 - 0.1587 ≈ 0.6826

Multiplying this area by 500, we get:

Number of students with height between 60 and 70 inches ≈ 500 * 0.6826 ≈ 341.3 ≈ 341 students

34.

a) A statistical hypothesis is a statement about a population parameter that can be tested using sample data. There are two types of hypotheses:

Null hypothesis (H0): a statement of no effect or no difference
Alternative hypothesis (H1): a statement of an effect or difference
b) Errors in hypothesis testing:

Type I error (α): rejecting the null hypothesis when it is true
Type II error (β): failing to reject the null hypothesis when it is false
c) A sample is a subset of data selected from a population. It is used to make inferences about the population.

Large samples: samples with a large number of observations, typically > 30
Small samples: samples with a small number of observations, typically < 30
35.

We are given a random sample of size 25 from a population, and the sample standard deviation is 9.0. We want to test the hypothesis that the population standard deviation is 10.5.

Using the chi-square distribution, we can test this hypothesis. The chi-square statistic is:

χ² = (n - 1) * (s^2 / σ^2)

where n is the sample size, s is the sample standard deviation, and σ is the population standard deviation.

χ² = (25 - 1) * (9.0^2 / 10.5^2) ≈ 15.38

The degrees of freedom for this test are n - 1 = 24. Using a chi-square distribution table, we find the critical value for χ² with 24 degrees of freedom and a significance level of 0.05:

χ²_critical ≈ 36.42

Since our calculated χ² value (15.38) is less than the critical value, we fail to reject the null hypothesis that the population standard deviation is 10.5.

37.

We are given the grades of 100 students in a Data Science paper, with frequencies:

Grade	Frequency
A	15
B	17
C	30
D	22
E	16
We want to test the hypothesis that the distribution of grades is uniform using the χ² test.

First, we calculate the expected frequencies under the null hypothesis of a uniform distribution:

Expected frequency = Total frequency / Number of categories = 100 / 5 = 20

Next, we calculate the χ² statistic:

χ² = Σ [(Observed frequency - Expected frequency)^2 / Expected frequency]

χ² = [(15 - 20)^2 / 20 + (17 - 20)^2 / 20 + (30 - 20)^2 / 20 + (22 - 20)^2 / 20 + (16 - 20)^2 / 20] ≈ 10.5

The degrees of freedom for this test are k - 1, where k is the number of categories. In this case, k = 5,




New Chat

Follow


38. Anova Test:

The ANOVA (Analysis of Variance) test is a statistical test used to compare the means of two or more groups to determine if there is a significant difference between them. The test assumes that the data is normally distributed and that the variances of the groups are equal.

Here's an example of how to perform an ANOVA test in Python using the statsmodels library:

 39.How would you create a basic Flask route that displays "Hello, World!" on the homepage?


```python
from flask import Flask

app = Flask(__name__)

@app.route('/')
def hello_world():
    return 'Hello, World!'

if __name__ == '__main__':
    app.run()
```

     * Serving Flask app "__main__" (lazy loading)
     * Environment: production
    [31m   WARNING: This is a development server. Do not use it in a production deployment.[0m
    [2m   Use a production WSGI server instead.[0m
     * Debug mode: off
    

     * Running on http://127.0.0.1:5000/ (Press CTRL+C to quit)
    

 40.Explain how to set up a Flask application to handle form submissions using POST requests


```python
from flask import Flask, request

app = Flask(__name__)

@app.route('/submit', methods=['POST'])
def submit_form():
    data = request.form
    # Process the data
    return 'Form submitted successfully!'

if __name__ == '__main__':
    app.run()
```


```python
 41.Write a Flask route that accepts a parameter in the URL and displays it on the page
```


```python
from flask import Flask

app = Flask(__name__)

@app.route('/hello/<name>')
def hello_name(name):
    return f'Hello, {name}!'

if __name__ == '__main__':
    app.run()
```


```python
 42.How can you implement user authentication in a Flask application
```


```python
from flask import Flask, redirect, url_for
from flask_login import LoginManager, UserMixin, login_required, login_user, logout_user

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret_key'

login_manager = LoginManager(app)

class User(UserMixin):
    def __init__(self, id):
        self.id = id

@login_manager.user_loader
def load_user(user_id):
    return User(user_id)

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    # Authenticate the user
    user = User(1)
    login_user(user)
    return redirect(url_for('protected'))

@app.route('/protected')
@login_required
def protected():
    return 'Hello, authenticated user!'

if __name__ == '__main__':
    app.run()
```


```python
 43.Describe the process of connecting a Flask app to a SQLite database using SQLAlchemy.
```


```python
from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)

@app.route('/')
def index():
    users = User.query.all()
    return 'Hello, World!'

if __name__ == '__main__':
    app.run()
```


```python
 44.How would you create a RESTful API endpoint in Flask that returns JSON data
```


```python
from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/api/data', methods=['GET'])
def get_data():
    data = {'name': 'John', 'age': 30}
    return jsonify(data)

if __name__ == '__main__':
    app.run()
```

 45.Explain how to use Flask-WTF to create and validate forms in a Flask application


```python
from flask import Flask, render_template
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret_key'

class MyForm(FlaskForm):
    name = StringField('Name', validators=[DataRequired()])
    submit = SubmitField('Submit')

@app.route('/form', methods=['GET', 'POST'])
def form():
    form = MyForm()
    if form.validate_on
```


```python
 46.How can you implement file uploads in a Flask application?
```


```python
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/upload', methods=['POST'])
def upload_file():
    file = request.files['file']
    # Save the file to a directory
    file.save('/path/to/directory/' + file.filename)
    return jsonify({'message': 'File uploaded successfully!'})

if __name__ == '__main__':
    app.run()
```


```python
 47.Describe the steps to create a Flask blueprint and why you might use one
```


```python
from flask import Blueprint, render_template

my_blueprint = Blueprint('my_blueprint', __name__)

@my_blueprint.route('/hello')
def hello():
    return render_template('hello.html')

app.register_blueprint(my_blueprint)
```

 48.How would you deploy a Flask application to a production server using Gunicorn and Nginx


```python
To deploy a Flask application to a production server using Gunicorn and Nginx, you can follow these steps:

Install Gunicorn and Nginx on your server
Create a wsgi.py file to serve your Flask application
Configure Gunicorn to run your application
Configure Nginx to proxy requests to Gunicorn
Start Gunicorn and Nginx
Here's an example of how to configure Gunicorn and Nginx:

bash


```


```python
# wsgi.py
from myapp import app

if __name__ == '__main__':
    app.run()

# gunicorn.conf.py
import os

bind = '0.0.0.0:5000'
workers = 3

# nginx.conf
http {
    server {
        listen 80;
        server_name example.com;

        location / {
            proxy_pass http://localhost:5000;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
        }
    }
}
```


```python
49. Make a fully functional web application using flask, Mangodb. Signup,Signin page.And after successfully 
login .Say hello Geeks message at webpage.
```


```python
from flask import Flask, render_template, request, redirect, url_for
from flask_pymongo import PyMongo
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['MONGO_URI'] = 'mongodb://localhost:27017/mydatabase'
mongo = PyMongo(app)

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        # Hash the password
        password_hash = generate_password_hash(password)
        # Save the user to the database
        mongo.db.users.insert_one({'username': username, 'password': password_hash})
        return redirect(url_for('signin'))
    return render_template('signup.html')

@app.route('/signin', methods=['GET', 'POST'])
def signin():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        # Find the user in the database
        user = mongo.db.users.find_one({'username': username})
        if user and check_password_hash(user['password'], password):
            # Login the user
            return redirect(url_for('hello'))
    return render_template('signin.html')

@app.route('/hello')
def hello():
    return 'Hello, Geeks!'

if __name__ == '__main__':
    app.run()
```

 50.Machine Learning
    
 What is the difference between Series & Dataframes 
Create a database name Travel_Planner in mysql ,and  create a table name bookings in that which having 
attributes (user_id INT,  flight_id INT,hotel_id INT, activity_id INT,booking_date DATE) .fill with some dummy 
value .Now you have to read the content of this table using pandas as dataframe.Show the output
 Difference between loc and iloc
    
 What is the difference between supervised and unsupervised learning

 Explain the bias-variance tradeoff
    
 What are precision and recall? How are they different from accuracy

What is overfitting and how can it be prevented?

Explain the concept of cross-validation

 What is the difference between a classification and a regression problem
    
 Explain the concept of ensemble learning

 What is gradient descent and how does it work
    
 Describe the difference between batch gradient descent and stochastic gradient descent

 What is the curse of dimensionality in machine learning
    
 Explain the difference between L1 and L2 regularization

 What is a confusion matrix and how is it used
    
 Define AUC-ROC curve

 Explain the k-nearest neighbors algorithm
    
 Explain the basic concept of a Support Vector Machine (SVM)

 How does the kernel trick work in SVM
    
 What are the different types of kernels used in SVM and when would you use each

 What is the hyperplane in SVM and how is it determined
    
 What are the pros and cons of using a Support Vector Machine (SVM)

 Explain the difference between a hard margin and a soft margin SVM
    
 Describe the process of constructing a decision tree

 Describe the working principle of a decision tree
    
 What is information gain and how is it used in decision trees

 Explain Gini impurity and its role in decision trees
    
 What are the advantages and disadvantages of decision trees

 How do random forests improve upon decision trees
    
 How does a random forest algorithm work

 What is bootstrapping in the context of random forests
    
 Explain the concept of feature importance in random forests

 Describe the logistic regression model and its assumptions
    
 What are the key hyperparameters of a random forest and how do they affect the model

 How does logistic regression handle binary classification problems
    
 What is the sigmoid function and how is it used in logistic regression

 Explain the concept of the cost function in logistic regression
    
 How can logistic regression be extended to handle multiclass classification

 What is the difference between L1 and L2 regularization in logistic regression
    
 What is XGBoost and how does it differ from other boosting algorithms

 Explain the concept of boosting in the context of ensemble learning
    
 How does XGBoost handle missing values

 What are the key hyperparameters in XGBoost and how do they affect model performance
    
 Describe the process of gradient boosting in XGBoost

 What are the advantages and disadvantages of using XGBoost?


What is the difference between Series & Dataframes?

In pandas, a Series is a one-dimensional labeled array of values, while a DataFrame is a two-dimensional labeled data structure with columns of potentially different types. A Series is similar to a column in a spreadsheet, while a DataFrame is similar to a spreadsheet itself.


```python
import mysql.connector
import pandas as pd

# Create a connection to the database
cnx = mysql.connector.connect(
    user='username',
    password='password',
    host='localhost',
    database='Travel_Planner'
)

# Create a cursor object
cursor = cnx.cursor()

# Create the table
cursor.execute("""
    CREATE TABLE bookings (
        user_id INT,
        flight_id INT,
        hotel_id INT,
        activity_id INT,
        booking_date DATE
    )
""")

# Insert some dummy data
cursor.execute("""
    INSERT INTO bookings (user_id, flight_id, hotel_id, activity_id, booking_date)
    VALUES (1, 1, 1, 1, '2022-01-01'),
           (2, 2, 2, 2, '2022-01-02'),
           (3, 3, 3, 3, '2022-01-03')
""")

# Commit the changes
cnx.commit()

# Read the content of the table using pandas
df = pd.read_sql_table('bookings', cnx)

print(df)
```


```python
df.loc[0, 'user_id']
```


```python
df.iloc[0, 0]
```

Difference between supervised and unsupervised learning

Supervised learning is a type of machine learning where the model is trained on labeled data, and the goal is to make predictions on new, unseen data. Unsupervised learning is a type of machine learning where the model is trained on unlabeled data, and the goal is to discover patterns or structure in the data.


```python
Bias-variance tradeoff

The bias-variance tradeoff is a fundamental concept in machine learning that refers to the tradeoff between the error introduced by a model's simplifying assumptions (bias) and the error introduced by the noise in the data (variance). A model with high bias pays little attention to the training data and oversimplifies the problem, while a model with high variance is highly sensitive to the training data and overfits the problem.

Precision and recall

Precision and recall are two metrics used to evaluate the performance of a classification model. Precision is the ratio of true positives to the sum of true positives and false positives, while recall is the ratio of true positives to the sum of true positives and false negatives.

Overfitting and cross-validation

Overfitting occurs when a model is too complex and performs well on the training data but poorly on new, unseen data. Cross-validation is a technique used to prevent overfitting by training and evaluating a model on multiple subsets of the data.

I'll stop here for now. Let me know if you'd like me to continue with the rest of the questions!



Verify

Open In Editor
Edit
Copy code
   user_id  flight_id  hotel_id  activity_id booking_date
0        1          1         1            1   2022-01-01
1        2          2         2            2   2022-01-02
2        3          3         3            3   2022-01-03
Is this code good?


The code I provided earlier is a good starting point, but there are a few things that could be improved.

Firstly, the code assumes that the database connection is successful, but it doesn't handle any potential errors that might occur. It's always a good idea to add some error handling to make the code more robust.

Secondly, the code uses the mysql-connector-python library to connect to the MySQL database,

Scroll to bottom

```

What are precision and recall? How are they different from accuracy?

Precision and recall are two metrics used to evaluate the performance of a classification model.

Precision is the ratio of true positives (correctly predicted instances) to the sum of true positives and false positives (incorrectly predicted instances). It measures how accurate the model is when it predicts a positive outcome.

Recall is the ratio of true positives to the sum of true positives and false negatives (missed instances). It measures how well the model detects all instances of a particular class.

Accuracy, on the other hand, is the ratio of correct predictions to the total number of predictions. It measures the overall performance of the model.

Here's an example to illustrate the difference:

Suppose we have a model that predicts whether an email is spam or not. The model predicts 90 emails as spam, out of which 80 are actually spam and 10 are not. The model misses 10 spam emails.

Precision: 80/90 = 0.89 (89% of predicted spam emails are actually spam)
Recall: 80/90 = 0.89 (89% of actual spam emails are detected)
Accuracy: (80 + 10) / 100 = 0.90 (90% of emails are correctly classified)
What is overfitting and how can it be prevented?

Overfitting occurs when a model is too complex and performs well on the training data but poorly on new, unseen data. This happens when the model is too specialized to the training data and fails to generalize well to new data.

Overfitting can be prevented by:

Regularization techniques, such as L1 and L2 regularization, which add a penalty term to the loss function to discourage large weights.
Early stopping, which stops training when the model's performance on the validation set starts to degrade.
Data augmentation, which increases the size of the training set by applying transformations to the existing data.
Cross-validation, which evaluates the model on multiple subsets of the data to avoid overfitting to a particular subset.
Explain the concept of cross-validation

Cross-validation is a technique used to evaluate the performance of a model on unseen data. It involves dividing the available data into multiple subsets, training the model on one subset, and evaluating its performance on another subset. This process is repeated multiple times, and the average performance across all subsets is used to estimate the model's performance on new data.

There are several types of cross-validation, including:

K-fold cross-validation, which divides the data into k subsets and trains the model on k-1 subsets, evaluating its performance on the remaining subset.
Leave-one-out cross-validation, which trains the model on all but one instance, evaluating its performance on that instance.
What is the difference between a classification and a regression problem?

A classification problem involves predicting a categorical label or class, such as spam vs. not spam, or dog vs. cat. The goal is to assign a label to a new instance based on the patterns learned from the training data.

A regression problem, on the other hand, involves predicting a continuous value, such as a stock price or a temperature. The goal is to predict a numerical value based on the patterns learned from the training data.

Explain the concept of ensemble learning

Ensemble learning involves combining the predictions of multiple models to improve the overall performance. The idea is that multiple models can provide a more accurate and robust prediction than a single model.

There are several types of ensemble learning, including:

Bagging, which involves training multiple models on different subsets of the data and combining their predictions.
Boosting, which involves training multiple models on the same data, with each model focusing on the mistakes made by the previous model.
Stacking, which involves training a meta-model to combine the predictions of multiple models.
What is gradient descent and how does it work?

Gradient descent is an optimization algorithm used to minimize the loss function in machine learning. It works by iteratively updating the model's parameters in the direction of the negative gradient of the loss function.

The gradient descent algorithm consists of the following steps:

Initialize the model's parameters
Compute the loss function and its gradient with respect to the parameters
Update the parameters in the direction of the negative gradient
Repeat steps 2-3 until convergence or a stopping criterion is reached
Describe the difference between batch gradient descent and stochastic gradient descent

Batch gradient descent involves computing the gradient of the loss function using the entire training set and updating the parameters accordingly. This can be computationally expensive and may not be feasible for large datasets.

Stochastic gradient descent, on the other hand, involves computing the gradient of the loss function using a single instance or a small batch of instances and updating the parameters accordingly. This is faster and more efficient, but may not converge as quickly as batch gradient descent.

I'll stop here for now. Let me

I'd be happy to help with these machine learning questions.

What is the curse of dimensionality in machine learning?

The curse of dimensionality refers to the problem that arises when dealing with high-dimensional data, where the number of features or dimensions is very large. This can lead to several issues, including:

Data becomes increasingly sparse and difficult to analyze
Noise and irrelevant features can dominate the signal
Computational complexity increases exponentially with the number of dimensions
Models become prone to overfitting
To mitigate the curse of dimensionality, techniques such as feature selection, dimensionality reduction (e.g., PCA, t-SNE), and regularization can be used.

Explain the difference between L1 and L2 regularization

L1 and L2 regularization are two types of regularization techniques used to prevent overfitting in machine learning models.

L1 regularization, also known as Lasso regularization, adds a term to the loss function that is proportional to the absolute value of the model's weights. This encourages the model to set some weights to zero, effectively reducing the number of features used.

L2 regularization, also known as Ridge regularization, adds a term to the loss function that is proportional to the square of the model's weights. This encourages the model to reduce the magnitude of the weights, but does not set them to zero.

L1 regularization is useful for feature selection, while L2 regularization is useful for reducing overfitting.

What is a confusion matrix and how is it used?

A confusion matrix is a table used to evaluate the performance of a classification model. It compares the predicted classes against the actual classes, and provides a summary of the number of true positives, false positives, true negatives, and false negatives.

A confusion matrix is typically used to calculate metrics such as accuracy, precision, recall, and F1-score.

Define AUC-ROC curve

The AUC-ROC curve is a plot of the true positive rate against the false positive rate at different thresholds. It is used to evaluate the performance of a binary classification model.

AUC stands for Area Under the Curve, and ROC stands for Receiver Operating Characteristic. The AUC-ROC curve provides a single number that summarizes the model's performance, with higher values indicating better performance.

Explain the k-nearest neighbors algorithm

The k-nearest neighbors (KNN) algorithm is a simple, non-parametric classification algorithm that works by finding the k most similar instances to a new instance, and using their labels to make a prediction.

The algorithm consists of the following steps:

Calculate the distance between the new instance and each instance in the training set
Select the k instances with the smallest distance
Use the labels of the k instances to make a prediction
KNN is a lazy learning algorithm, meaning that it does not build a model until a new instance is presented. It is sensitive to the choice of k and the distance metric used.

Explain the basic concept of a Support Vector Machine (SVM)

A Support Vector Machine (SVM) is a type of supervised learning algorithm that can be used for classification or regression tasks. The basic concept of an SVM is to find a hyperplane that maximally separates the classes in the feature space.

The algorithm works by:

Mapping the input data into a higher-dimensional feature space using a kernel function
Finding the hyperplane that maximally separates the classes in the feature space
Using the hyperplane to make predictions on new instances
How does the kernel trick work in SVM?

The kernel trick is a mathematical technique used in SVMs to map the input data into a higher-dimensional feature space. This allows the algorithm to find a hyperplane that is not linearly separable in the original feature space, but is linearly separable in the higher-dimensional space.

The kernel trick works by defining a kernel function that computes the dot product of two instances in the feature space, without explicitly computing the feature space itself. This allows the algorithm to operate in the original feature space, while still benefiting from the higher-dimensional feature space.

What are the different types of kernels used in SVM and when would you use each?

There are several types of kernels used in SVMs, including:

Linear kernel: used for linearly separable data
Polynomial kernel: used for non-linearly separable data, with a polynomial relationship between the features
Radial Basis Function (RBF) kernel: used for non-linearly separable data, with a Gaussian relationship between the features
Sigmoid kernel: used for non-linearly separable data, with a sigmoidal relationship between the features
The choice of kernel depends on the nature of the data and the problem being solved.

What is the hyperplane in SVM and how is it determined?

The hyperplane is a decision boundary that separates the classes in the feature space. In SVMs, the hyperplane is determined by finding the hyperplane that maximally separates the classes, while also minimizing the




New Chat



Describe the process of constructing a decision tree

The process of constructing a decision tree involves the following steps:

Select a root node: Choose a feature to split the data at the root node.
Split the data: Split the data into two subsets based on the selected feature and a threshold value.
Create child nodes: Create two child nodes, one for each subset of data.
Recursively split the data: Repeat steps 1-3 for each child node until a stopping criterion is reached, such as a maximum depth or a minimum number of instances.
Assign labels: Assign a label to each leaf node based on the majority class or a prediction model.
Describe the working principle of a decision tree

A decision tree works by recursively partitioning the data into smaller subsets based on the values of the input features. Each internal node represents a feature or attribute, and each leaf node represents a class label or prediction. The tree is traversed from the root node to a leaf node, and the class label or prediction is determined based on the path taken.

What is information gain and how is it used in decision trees

Information gain is a measure of the reduction in impurity or uncertainty in the data after splitting it based on a feature. It is used in decision trees to select the best feature to split the data at each node. The feature with the highest information gain is chosen to split the data.

Explain Gini impurity and its role in decision trees

Gini impurity is a measure of the impurity or uncertainty in the data. It is used in decision trees to determine the best feature to split the data at each node. The Gini impurity is calculated as the probability of misclassifying an instance, and the feature with the lowest Gini impurity is chosen to split the data.

What are the advantages and disadvantages of decision trees

Advantages:

Easy to interpret and visualize
Can handle both categorical and numerical features
Can handle missing values
Fast training and prediction times
Disadvantages:

Prone to overfitting
Can be sensitive to the choice of features and hyperparameters
Can be computationally expensive for large datasets
How do random forests improve upon decision trees

Random forests improve upon decision trees by:

Reducing overfitting through bagging and feature randomization
Improving accuracy through ensemble learning
Handling high-dimensional data and correlated features
Providing feature importance and selection
How does a random forest algorithm work

A random forest algorithm works by:

Creating multiple decision trees on random subsets of the data and features
Training each tree on a random subset of the data and features
Combining the predictions of each tree to make a final prediction
Using bagging and feature randomization to reduce overfitting and improve accuracy
What is bootstrapping in the context of random forests

Bootstrapping is a technique used in random forests to create multiple decision trees on random subsets of the data. Each tree is trained on a random subset of the data, and the predictions of each tree are combined to make a final prediction.

Explain the concept of feature importance in random forests

Feature importance is a measure of the contribution of each feature to the predictions made by a random forest. It is calculated as the average decrease in impurity or accuracy when a feature is randomly permuted. Features with high importance are more important for the predictions made by the model.

Describe the logistic regression model and its assumptions

Logistic regression is a linear model that predicts the probability of a binary response based on one or more predictor variables. The assumptions of logistic regression include:

Linearity: The relationship between the predictor variables and the log-odds of the response variable is linear.
Independence: Each instance is independent of the others.
Homoscedasticity: The variance of the response variable is constant across all levels of the predictor variables.
Normality: The predictor variables are normally distributed.
What are the key hyperparameters of a random forest and how do they affect the model

The key hyperparameters of a random forest include:

Number of trees (n_estimators): Affects the accuracy and computational complexity of the model.
Maximum depth (max_depth): Affects the complexity and accuracy of the model.
Number of features to consider at each split (max_features): Affects the accuracy and computational complexity of the model.
Minimum sample size for splitting (min_samples_split): Affects the accuracy and computational complexity of the model.
How does logistic regression handle binary classification problems

Logistic regression handles binary classification problems by predicting the probability of the positive class based on the input features. The probability is calculated using the sigmoid function, and the class label is determined based on a threshold value.

What is the sigmoid function and how is it used in logistic regression

The sigmoid function is a mathematical function that maps the




New Chat



How does XGBoost handle missing values

XGBoost handles missing values by using a default direction, which is specified by the missing parameter. The default direction can be either nan (missing values are treated as NaN) or a specific value (e.g., 0 or -1). When a missing value is encountered, XGBoost will use the default direction to determine how to split the data.

Alternatively, XGBoost also provides an option to use a separate tree to handle missing values, which can be specified by the missing parameter. This approach can be useful when the missing values have a specific pattern or distribution.

What are the key hyperparameters in XGBoost and how do they affect model performance

The key hyperparameters in XGBoost include:

max_depth: The maximum depth of the tree. Increasing max_depth can improve accuracy but also increase the risk of overfitting.
learning_rate: The step size shrinkage used in each iteration. Decreasing learning_rate can improve accuracy but also increase the number of iterations.
n_estimators: The number of trees to be built. Increasing n_estimators can improve accuracy but also increase computational complexity.
gamma: The minimum loss reduction required to make a further partition on a leaf node. Increasing gamma can reduce overfitting but also increase computational complexity.
subsample: The subsample ratio of the training instance. Decreasing subsample can reduce overfitting but also increase computational complexity.
colsample_bytree: The subsample ratio of columns when constructing each tree. Decreasing colsample_bytree can reduce overfitting but also increase computational complexity.
reg_alpha and reg_lambda: The L1 and L2 regularization parameters, respectively. Increasing these parameters can reduce overfitting but also increase computational complexity.
Describe the process of gradient boosting in XGBoost

The process of gradient boosting in XGBoost involves the following steps:

Initialize the model with a constant value.
For each iteration, compute the gradient of the loss function with respect to the current model.
Compute the gradient statistics (e.g., mean and variance) for each feature.
Select the feature with the highest gradient statistic to split the data.
Split the data into two subsets based on the selected feature and a threshold value.
Compute the gain of the split, which is the reduction in loss after splitting the data.
If the gain is positive, create a new tree node and recursively split the data.
Otherwise, stop splitting and return the current model.
Update the model by adding the new tree node to the ensemble.
Repeat steps 2-9 until the maximum number of iterations is reached.
What are the advantages and disadvantages of using XGBoost?

Advantages:

High accuracy: XGBoost is known for its high accuracy and ability to handle complex interactions between features.
Fast training: XGBoost is highly optimized and can train models quickly, even on large datasets.
Handling missing values: XGBoost can handle missing values effectively, which is a common problem in real-world datasets.
Parallelization: XGBoost can be parallelized, which makes it suitable for large-scale datasets.
Disadvantages:

Overfitting: XGBoost can be prone to overfitting, especially when the number of iterations is high or the learning rate is too high.
Computational complexity: XGBoost can be computationally expensive, especially when dealing with large datasets.
Hyperparameter tuning: XGBoost has many hyperparameters that need to be tuned, which can be time-consuming and require expertise.
Interpretability: XGBoost models can be difficult to interpret, especially for non-technical users.



New Chat




```python
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load the dataset
file_path = '/mnt/data/dataset[1].csv'
lung_cancer_data = pd.read_csv(r"C:\Users\malik\Desktop\DATA SCIENCE USING PYTHON pROGRAMING\dataset.csv")

# Display summary statistics
summary_stats = lung_cancer_data.describe()
print("Summary Statistics:\n", summary_stats)

# Gender distribution
gender_distribution = lung_cancer_data['GENDER'].value_counts()

plt.figure(figsize=(8, 6))
sns.countplot(x='GENDER', data=lung_cancer_data, palette='Set2')
plt.title('Gender Distribution')
plt.xlabel('Gender')
plt.ylabel('Count')
plt.show()

print("Gender Distribution:\n", gender_distribution)

# Lung cancer distribution
lung_cancer_distribution = lung_cancer_data['LUNG_CANCER'].value_counts()

plt.figure(figsize=(8, 6))
sns.countplot(x='LUNG_CANCER', data=lung_cancer_data, palette='Set1')
plt.title('Lung Cancer Distribution')
plt.xlabel('Lung Cancer')
plt.ylabel('Count')
plt.show()

print("Lung Cancer Distribution:\n", lung_cancer_distribution)

# Correlation matrix
correlation_matrix = lung_cancer_data.corr()

plt.figure(figsize=(12, 10))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt='.2f')
plt.title('Correlation Matrix')
plt.show()

```

    Summary Statistics:
                    AGE      SMOKING  YELLOW_FINGERS      ANXIETY  PEER_PRESSURE  \
    count  3000.000000  3000.000000     3000.000000  3000.000000    3000.000000   
    mean     55.169000     1.491000        1.514000     1.494000       1.499000   
    std      14.723746     0.500002        0.499887     0.500047       0.500082   
    min      30.000000     1.000000        1.000000     1.000000       1.000000   
    25%      42.000000     1.000000        1.000000     1.000000       1.000000   
    50%      55.000000     1.000000        2.000000     1.000000       1.000000   
    75%      68.000000     2.000000        2.000000     2.000000       2.000000   
    max      80.000000     2.000000        2.000000     2.000000       2.000000   
    
           CHRONIC_DISEASE      FATIGUE      ALLERGY     WHEEZING  \
    count      3000.000000  3000.000000  3000.000000  3000.000000   
    mean          1.509667     1.489667     1.506667     1.497333   
    std           0.499990     0.499977     0.500039     0.500076   
    min           1.000000     1.000000     1.000000     1.000000   
    25%           1.000000     1.000000     1.000000     1.000000   
    50%           2.000000     1.000000     2.000000     1.000000   
    75%           2.000000     2.000000     2.000000     2.000000   
    max           2.000000     2.000000     2.000000     2.000000   
    
           ALCOHOL_CONSUMING     COUGHING  SHORTNESS_OF_BREATH  \
    count        3000.000000  3000.000000          3000.000000   
    mean            1.491333     1.510667             1.488000   
    std             0.500008     0.499970             0.499939   
    min             1.000000     1.000000             1.000000   
    25%             1.000000     1.000000             1.000000   
    50%             1.000000     2.000000             1.000000   
    75%             2.000000     2.000000             2.000000   
    max             2.000000     2.000000             2.000000   
    
           SWALLOWING_DIFFICULTY   CHEST_PAIN  
    count            3000.000000  3000.000000  
    mean                1.489667     1.498667  
    std                 0.499977     0.500082  
    min                 1.000000     1.000000  
    25%                 1.000000     1.000000  
    50%                 1.000000     1.000000  
    75%                 2.000000     2.000000  
    max                 2.000000     2.000000  
    


    
![png](output_169_1.png)
    


    Gender Distribution:
     M    1514
    F    1486
    Name: GENDER, dtype: int64
    


    
![png](output_169_3.png)
    


    Lung Cancer Distribution:
     YES    1518
    NO     1482
    Name: LUNG_CANCER, dtype: int64
    


    
![png](output_169_5.png)
    


2. Do the Eda on this Dataset :Presidential Election Polls 2024 Dataset and extract useful information from 
this


```python
import pandas as pd

# Load the dataset (assuming you have the dataset as 'election_polls_2024.csv')
# Replace 'election_polls_2024.csv' with the actual path to your dataset
df = pd.read_csv(r"C:\Users\malik\Downloads\election2024.csv")

# Preview the first few rows of the dataset
print(df.head())

# Get basic information about the dataset
print(df.info())

# Summary statistics for numerical columns
print(df.describe())

# Summary statistics for categorical columns
print(df.describe(include=['object']))

# Check for missing values
print(df.isnull().sum())

# Distribution of categorical features
print(df['sex'].value_counts())
print(df['federal_district'].value_counts())
print(df['type_of_city'].value_counts())
print(df['knows_election_date'].value_counts())
print(df['will_vote'].value_counts())
print(df['candidate'].value_counts())
print(df['television_usage'].value_counts())
print(df['internet_usage'].value_counts())
print(df['education'].value_counts())
print(df['income'].value_counts())
print(df['employment'].value_counts())

# For missing values in 'job_type' and 'company_type'
print(df[['job_type', 'company_type']].isnull().sum())

# Visualizations (you can expand this section based on specific analysis)
import matplotlib.pyplot as plt
import seaborn as sns

# Example: Distribution of age
plt.figure(figsize=(10, 6))
sns.histplot(df['age'], bins=30, kde=True)
plt.title('Age Distribution of Respondents')
plt.xlabel('Age')
plt.ylabel('Frequency')
plt.show()

# Example: Candidate preference distribution
plt.figure(figsize=(10, 6))
sns.countplot(x='candidate', data=df, order=df['candidate'].value_counts().index)
plt.title('Candidate Preference')
plt.xlabel('Candidate')
plt.ylabel('Number of Respondents')
plt.xticks(rotation=45)
plt.show()

```

                     id   sex   age federal_district  \
    0  07169ed8148ce047  male  18.0  north caucasian   
    1  0716a4f3354cecdd  male  23.0  north caucasian   
    2  0716889b304ce79c  male  20.0            volga   
    3  07168e28b5cce563  male  22.0     northwestern   
    4  0716a563914ce549  male  21.0         southern   
    
                                       type_of_city    knows_election_date  \
    0                                       village     named correct date   
    1                                       village     named correct date   
    2         city with population of less than 50k     named correct date   
    3  city with population of 1 million and higher  not sure or no answer   
    4  city with population of 1 million and higher     named correct date   
    
            will_vote candidate      television_usage      internet_usage  \
    0        not sure     Putin  several times a week  over 4 hours a day   
    1        not sure     Putin      once half a year  over 4 hours a day   
    2  definitely yes     Putin  several times a week  over 4 hours a day   
    3        not sure  Davankov  several times a week  over 4 hours a day   
    4  definitely yes     Putin        does not watch  over 4 hours a day   
    
                         education     income        employment  \
    0  incomplete school education  very high      entrepreneur   
    1                      college  very high     work for hire   
    2                      college  very high     work for hire   
    3                      college  very high        unemployed   
    4              bachelor degree  very high  employed student   
    
                      job_type                       company_type   weight1  
    0                      NaN                            farming  1.445172  
    1  commercial organization                              trade  1.445172  
    2   law enforcement agency             law enforcement agency  1.301691  
    3                      NaN                                NaN  1.538628  
    4  commercial organization  tech, programming, communications  1.967015  
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1600 entries, 0 to 1599
    Data columns (total 16 columns):
     #   Column               Non-Null Count  Dtype  
    ---  ------               --------------  -----  
     0   id                   1600 non-null   object 
     1   sex                  1600 non-null   object 
     2   age                  1600 non-null   float64
     3   federal_district     1600 non-null   object 
     4   type_of_city         1600 non-null   object 
     5   knows_election_date  1600 non-null   object 
     6   will_vote            1600 non-null   object 
     7   candidate            1600 non-null   object 
     8   television_usage     1600 non-null   object 
     9   internet_usage       1600 non-null   object 
     10  education            1600 non-null   object 
     11  income               1600 non-null   object 
     12  employment           1600 non-null   object 
     13  job_type             692 non-null    object 
     14  company_type         879 non-null    object 
     15  weight1              1600 non-null   float64
    dtypes: float64(2), object(14)
    memory usage: 200.1+ KB
    None
                   age      weight1
    count  1600.000000  1600.000000
    mean     49.936250     1.000000
    std      16.901797     0.327084
    min      18.000000     0.468226
    25%      37.000000     0.772224
    50%      49.000000     0.921724
    75%      64.000000     1.158913
    max      90.000000     2.515072
                          id     sex federal_district  \
    count               1600    1600             1600   
    unique              1600       2                8   
    top     07169ed8148ce047  female          central   
    freq                   1     843              425   
    
                                type_of_city knows_election_date       will_vote  \
    count                               1600                1600            1600   
    unique                                 7                   4               6   
    top     city with population of 100-500k  named correct date  definitely yes   
    freq                                 391                1361            1062   
    
           candidate         television_usage           internet_usage education  \
    count       1600                     1600                     1600      1600   
    unique         7                        6                        6         6   
    top        Putin  less than 4 hours a day  less than 4 hours a day   college   
    freq        1128                      490                      613       690   
    
            income     employment                 job_type  \
    count     1600           1600                      692   
    unique       6             11                        6   
    top     medium  work for hire  commercial organization   
    freq       949            535                      445   
    
                       company_type  
    count                       879  
    unique                       21  
    top     industry, manufacturing  
    freq                        138  
    id                       0
    sex                      0
    age                      0
    federal_district         0
    type_of_city             0
    knows_election_date      0
    will_vote                0
    candidate                0
    television_usage         0
    internet_usage           0
    education                0
    income                   0
    employment               0
    job_type               908
    company_type           721
    weight1                  0
    dtype: int64
    female    843
    male      757
    Name: sex, dtype: int64
    central            425
    volga              324
    siberian           188
    southern           182
    northwestern       151
    ural               134
    north caucasian    107
    far eastern         89
    Name: federal_district, dtype: int64
    city with population of 100-500k                391
    village                                         366
    city with population of 1 million and higher    307
    city with population of less than 50k           179
    city with population of 500-950k                170
    city with population of 50-100k                 106
    settlement                                       81
    Name: type_of_city, dtype: int64
    named correct date       1361
    not sure or no answer     165
    named correct year         55
    wrong answer               19
    Name: knows_election_date, dtype: int64
    definitely yes        1062
    likely yes             218
    not sure               166
    definitely no           86
    likely no               55
    struggle to answer      13
    Name: will_vote, dtype: int64
    Putin                 1128
    struggle to answer     164
    will not take part      96
    Davankov                67
    Kharitonov              63
    Slutskiy                55
    spoilt vote             27
    Name: candidate, dtype: int64
    less than 4 hours a day    490
    over 4 hours a day         436
    does not watch             332
    several times a week       204
    several times a month       76
    once half a year            62
    Name: television_usage, dtype: int64
    less than 4 hours a day    613
    over 4 hours a day         576
    does not use internet      259
    several times a week       107
    several times a month       27
    once half a year            18
    Name: internet_usage, dtype: int64
    college                        690
    bachelor degree                550
    school                         181
    academic degree                 95
    incomplete school education     80
    no school education              4
    Name: education, dtype: int64
    medium         949
    high           405
    low            149
    very high       48
    very low        34
    hard to say     15
    Name: income, dtype: int64
    work for hire           535
    unemployed pensioner    502
    self-employed           122
    employed pensioner      120
    unemployed              101
    entrepreneur             87
    parental leave           44
    employed student         37
    unemployed student       27
    hard to say              22
    refused to answer         3
    Name: employment, dtype: int64
    job_type        908
    company_type    721
    dtype: int64
    


    
![png](output_171_1.png)
    



    
![png](output_171_2.png)
    



```python

```
